#!/bin/bash

# This script is a simpler alias for the simulation script for backward compatibility
echo "Starting Polygon JIT strategy in simulation mode..."
./start-simulation.sh
